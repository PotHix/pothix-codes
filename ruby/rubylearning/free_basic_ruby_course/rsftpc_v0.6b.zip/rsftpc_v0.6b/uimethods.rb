# uimethods.rb
# User Interface methods

def show_welcom_msg
  puts ''
  puts "\nWelcom to Ruby Simple FTP Client!"
  STDOUT.flush
end

def show_lists cmd, cd, lists
  puts ''
  puts "=== #{/^s/ === cmd.to_s ? :SERVER : :CLIENT} Site ==="
  puts "Current directory is #{cd}"
  puts ''
  if /.a/ === cmd.to_s
    puts lists
  else
    puts lists.first(10)
    puts "-- #{lists.length} files/directories are exist."  if lists.length > 10
  end
  show_input_msg
end

def show_result args
  puts ''
  puts "#{args[0]} : #{args[1]}"
  show_input_msg
end

def show_bye_msg
  puts ''
  puts msg = "Thanks, bye. :)"
  $LOG.debug(msg)
end

def show_input_error_msg
  puts ''
  puts 'Input a correct number or a command (s,c,a,b,q,h)'
  show_input_msg
end

def show_input_msg
  puts ''
  print 'Select number or input command: '
  STDOUT.flush
end

def show_help_msg
  msg =<<-'EOS'
rsftpc v0.6 - 20080330

Use the following commands:
  s : show the list of file/directory names on FTP-server. max 10 lines.
  c : show the list of file/directory names on FTP-client. max 10 lines.
  a : show the list of file/directory names on current site. all(no limit).
  b : back to the parent directory and show the list  
  q : quit the program
  h : help (show this brief paragraph)
EOS
  puts ''
  puts msg
  show_input_msg
end

def get_user_input
  yield :s
  flag =:SERVER
  loop do
    case cmd = gets.chomp
      when /^q/
        yield :q
      when /^s/
        yield :s
        flag = :SERVER
      when /^c/
        yield :c
        flag = :CLIENT
      when /^b/
        yield flag == :SERVER ? :sb : :cb
      when /^\d/
        yield flag == :SERVER ? :sn : :cn , cmd.to_i
      when /^a/
        yield flag == :SERVER ? :sa : :ca
      when /^h/
        yield :h
      else
        yield :z
    end
  end
end
  
def accept_number obj, cmd, n, host_name
  case n
    when 0...obj.lists.length
      if obj.directory? n
        obj.cwd n
        yield
      else
        show_result obj.transfer_file(host_name, n)
      end
    else
      show_input_error_msg
  end
end
