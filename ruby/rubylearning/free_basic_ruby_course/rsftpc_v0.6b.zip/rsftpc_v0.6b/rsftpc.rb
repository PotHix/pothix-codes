# rsftpc.rb v0.6b
# Ruby Simple FTP Client
#
# Usage:
# ruby rsftpc.rb -h ftp.ibiblio.org -n 21 -u anonymous -p ashbb@gmail.com

STDOUT.sync = true

require 'logger'
$LOG = Logger.new('rsftpc.log', 'monthly')

require 'optparse'
require 'socket'
require 'ftpmodules'
require 'sftpc'
require 'ftpserver'
require 'ftpclient'
require 'getreplies'
require 'uimethods'

host_name = port_no = user_name = password = nil
opts = OptionParser.new
opts.on('-h VAL'){|v| host_name = v}
opts.on('-n VAL'){|v| port_no = v.to_i}
opts.on('-u VAL'){|v| user_name = v}
opts.on('-p VAL'){|v| password = v}
opts.parse!(ARGV)

SimpleFTPClient.open(host_name, port_no, user_name, password) do |sftpc|
  show_welcom_msg
  server = client = nil
  get_user_input do |cmd, n|
    case cmd
      when :s, :sa
        server = FtpServer.new host_name
        show_lists cmd, server.cd, server.lists
      when :c, :ca
        client = FtpClient.new
        show_lists cmd, client.cd, client.lists
      when :sb
        server.cdup
        server = FtpServer.new host_name
        show_lists cmd, server.cd, server.lists
      when :cb
        client.cdup
        client = FtpClient.new
        show_lists cmd, client.cd, client.lists
      when :sn
        accept_number(server, cmd, n, host_name) do
          server = FtpServer.new host_name
          show_lists cmd, server.cd, server.lists
        end
      when :cn
        accept_number(client, cmd, n, host_name) do
          client = FtpClient.new
          show_lists cmd, client.cd, client.lists
        end
      when :q
         break
      when :h
        show_help_msg
      else
        show_input_error_msg
    end
  end
end
show_bye_msg
