# ftpmodules.rb
# FTP modules

module FTPmodules
  def mk_ls lists
    i = -1
    lists.collect do |list|
      type = (list[0,1] == 'd' ? 'd' : '-')
      "%d%s: %s" % [i += 1 , type, list.split.last]
    end
  end

  def mk_port
    msg = 'PASV ' << "\r\n"
    $SOCK.puts msg
    reply = $SOCK.getreplies msg
      
    rex = /(\d*,\d*,\d*,\d*),(\d*),(\d*)/  
    md = rex.match(reply)
    md[2].to_i * 256 + md[3].to_i
  end
  
  def directory? n
    @lists[n][@lists[n].index(':') -1, 1] == 'd'
  end
end
