# ftpclient.rb
# FTP Client

class FtpClient
  include FTPmodules
  
  def initialize
    @cd = Dir.pwd
    @lists = mk_ls Dir.glob("*").collect{|f| File.ftype(f)[0,1] + ' ' + f}
  end
  attr_reader :cd, :lists
  
  def transfer_file host_name, n
    port = mk_port
    file = msg =nil
    TCPSocket.open(host_name, port) do |dc|
      file =@lists[n].split.last
      msg = "STOR " << file << "\r\n"
      $SOCK.puts msg
      dc.puts  open(file, "rb").read
    end
    reply = $SOCK.getreplies msg
    return file, reply
  end
  
  def cwd n
    Dir.chdir @lists[n].split.last
  end
  
  def cdup
    Dir.chdir ".."
  end
  
end
