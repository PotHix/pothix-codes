# getreplies.rb
# Get Replies

class TCPSocket
  def getreply *msg
    $LOG.info(msg.to_s)  unless msg.empty?
    reply = line = gets
    code = line[0..2]
    if line[3,1] == '-'
      reply << (line = gets)  until line[0..3] == (code + ' ')
    end
    $LOG.info(reply.to_s)
    return reply
  end
  
  def getreplies *msg
    msg.empty? ? (reply = getreply) : (reply = getreply msg) 
    reply = getreply  while reply[0,1] == '1'
    return reply
  end
end
