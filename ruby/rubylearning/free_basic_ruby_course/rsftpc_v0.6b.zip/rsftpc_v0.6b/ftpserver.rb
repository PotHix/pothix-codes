# ftpserver.rb
# FTP Server

class FtpServer  
  include FTPmodules
  
  def initialize host_name
    @cd, @lists = get_pwd , get_lists(host_name)
  end
  attr_reader :cd, :lists
  
  def get_pwd
    msg = 'PWD ' << "\r\n"
    $SOCK.puts msg
    reply = $SOCK.getreplies msg
    rex = /"(.*)"/  
    md = rex.match(reply)
    return md[1]
  end
  
  def get_lists host_name
    port = mk_port
    msg = nil
    lists = []
    TCPSocket.open(host_name, port) do |dc|
      msg = "LIST \r\n"
      $SOCK.puts msg
      while m = dc.gets
        lists << m.chomp
      end
    end
    $SOCK.getreplies msg
    return mk_ls(lists)
  end
  
  def transfer_file host_name, n
    port = mk_port
    file = msg = nil
    TCPSocket.open(host_name, port) do |dc|
      file =@lists[n].split.last
      msg = "RETR " << file << "\r\n"
      $SOCK.puts msg
      data = dc.read
      open(file, "wb") {|f| f.puts data}
    end
    reply = $SOCK.getreplies msg
    return file, reply
  end
  
  def cwd  n
    msg = 'CWD ' << @lists[n].split.last << "\r\n"
    $SOCK.puts msg
    reply = $SOCK.getreplies msg
  end
  
  def cdup
    msg = 'CDUP ' << "\r\n"
    $SOCK.puts msg
    reply = $SOCK.getreplies msg
  end
  
end


