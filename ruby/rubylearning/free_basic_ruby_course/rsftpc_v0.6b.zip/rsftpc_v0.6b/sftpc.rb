# sftpc.rb
# Simple FTP Client

class SimpleFTPClient
  def self.open *args
    if block_given?
      begin
        sftpc = self.new args
        yield sftpc
      ensure
        sftpc.close
      end
    else
      self.new args
    end
  end
 
  def initialize args
    @host_name, @port_no, @user_name, @password = args
    $SOCK = login
  end
  
  def login
    sock = TCPSocket.new(@host_name, @port_no)
    sock.getreplies
    msg = "USER " << @user_name << "\r\n"
    sock.puts msg
    sock.getreplies msg
    msg = "PASS " << @password << "\r\n"
    sock.puts msg
    sock.getreplies msg
    sock
  end
  private :login
   
  def close
    msg = "QUIT \r\n"
    $SOCK.puts msg
    $SOCK.getreplies
    $LOG.info(msg)
    $SOCK.close
  end
end