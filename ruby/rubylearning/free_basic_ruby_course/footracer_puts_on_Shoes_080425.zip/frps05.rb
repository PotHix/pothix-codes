# frps05.rb
# footracer puts on Shoes
# v0.5

$BASE_PATH = "D:/work/ruby/programs/footracer_puts_on_Shoes/05/"
require $BASE_PATH + 'racer05'
require $BASE_PATH + 'shoesracer00'
$START = 10
$GOAL = 200
$RAND = 8

course = 0
input = %W{Satoshi Willian Jose Anteaya Brad Michael Marcos}
racers = input.collect{|racer| ShoesRacer.new racer}
winners = []

Shoes.app do 
  flow :margin_left => 30, :margin_top => 20 do 
    para strong "FootRace Start!\n"
    para ' ' * 120, "|GOAL|\n\n"
    racers.each{|racer| para racer.name, "\n\n"}
  end
 
  animate(5) do |i|
    l = para ''
    racers.each_with_index do |racer, n|
      racer.avatar.nil? ? racer.avatar = image($BASE_PATH + 'mini_creature.png') : racer.run
      racer.avatar.move 100+racer.dist*2, 100+42*n
      winners << racer.name  if racer.goal?
    end
    unless winners.empty?
      l.replace 'Winners: ' + winners.join(' ')
      sleep 5
      quit
    end
    sleep(2)  if i == 0
  end
  
  button("Stop", :top => 0.8, :left => 0.8){ quit }
end
