# shoesracer00.rb
# ShoesRacer class
# v0.0

class ShoesRacer < Racer
  def initialize name
    super name
    @avatar = nil
  end
  attr_accessor :avatar
end