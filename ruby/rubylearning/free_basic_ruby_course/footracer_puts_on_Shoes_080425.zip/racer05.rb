# racer05.rb
# Racer class
# v0.5

class Racer
  def initialize name
    @name = name
    @time = @dist = @move = 0
  end
  attr_reader :name, :time, :dist, :move
  
  def run
    @move = rand $RAND
    @dist += @move
    @time += 1
  end
  
  def goal?
    $START + @dist > $GOAL
  end
end
