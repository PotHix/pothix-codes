class Ticket
  def venue
    'Town Hall'
  end
  def performer
    'Mark Twain'
  end
  def price
    5.50
  end
  def seat
    'Second Balcony, row J, seat 12'
  end
  def event
    "Author's reading"
  end
end