# p040myhash.rb
h = {'dog' => 'canine', 'cat' => 'feline', 'donkey' => 'asinine', 12 => 'dodecine'}
puts h.length  # 3
puts h['dog']   # 'canine'
puts h
puts h[12]