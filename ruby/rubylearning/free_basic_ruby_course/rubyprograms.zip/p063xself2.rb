# p063xself2.rb
class S
  def m
    puts 'Class S method m:'
    puts self
  end
end
s = S.new
s.m
