 class Klass
   def initialize(str)
     @str = str
   end
   def sayHello
     @str
   end
 end
 