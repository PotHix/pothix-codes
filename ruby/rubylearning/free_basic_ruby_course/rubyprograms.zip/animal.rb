#animal.rb
class Animal
  def display  
    'Class Animal: display method from Animal.'
  end  
  def run
    'Class Animal: run method from Animal.'
  end
end
