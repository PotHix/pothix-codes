# p060usemodule.rb
require 'p058mytrig'
require 'p059mymoral'
Trig.sin(Trig::PI/4)
Moral.sin(Moral::VERY_BAD)

