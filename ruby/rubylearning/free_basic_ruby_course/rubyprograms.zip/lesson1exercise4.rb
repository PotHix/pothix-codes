# lesson1exercise4.rb
=begin
puts 'You are ' + (979000000/60/60/24/365).to_s + ' years old.'
=end


puts "%05d".send(:%,123)

It is just another form to:
puts "%05d" % 123 