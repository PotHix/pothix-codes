class Shape
  def who
    'I am a Shape'
  end
end
