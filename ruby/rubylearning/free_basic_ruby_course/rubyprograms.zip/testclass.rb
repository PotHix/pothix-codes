class TestClass
  def test_method
    'Hello I am in TestClass'
  end
end
