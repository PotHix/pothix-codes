require 'testclass'

ob = TestClass.new
puts("Testing: #{ob.test_method()}")