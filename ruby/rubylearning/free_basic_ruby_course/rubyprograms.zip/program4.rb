# program4,rb
c = lambda { |i| puts i }
c.call(1) # => 1
c.call(2) # => 2