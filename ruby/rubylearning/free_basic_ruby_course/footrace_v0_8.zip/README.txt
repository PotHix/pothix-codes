FootRace Game

usage:
ruby footrace.rb

spec:
1.
Racers run toward the goal.
When the first racer meets the goal line, the game stops and then 
shows the winner.

2.
When multiple racers meet the goal line at a time, they are all winners.

3.
Use Curses module like the following:
  require 'curses'
  include Curses

4.
User inputs racers' names.

5.
Until user selects quit the game, user can play the game repeatedly.

6.
User interface image is:

-------------------------------------------------------------------
Footrace Started!

 satoshi  *********************************************     |
 anteaya  *****************************************************
 satish   ************************************************  |
 pygi     ****************************************************
 jose     *********************************************     |

Winners: anteaya  pygi

Again? (y/n):
-------------------------------------------------------------------

Have fun!

Regards,
Satoshi
