start = Time.now
puts 'Start: ' + start.to_s
puts ''
File.open('PendNotReceived.txt', 'r') do |f1|
#File.open('PendNotAuthorized.txt', 'r') do |f1|
	array_line = []
	value_object = []
	actual_supervisor = ''
	next_supervisor = ''
	total_supervisor = 0
	#puts value_object.methods
	while line = f1.gets
		array_line = line.split(',')
		next_supervisor = array_line[0]
		if actual_supervisor == '' ;  actual_supervisor = array_line[0] ; end
		if actual_supervisor != next_supervisor
			puts ">>> Total Supervisor: #{actual_supervisor} is: #{total_supervisor}"
			total_supervisor = 0
			actual_supervisor = array_line[0]
		end
		total_supervisor = total_supervisor + array_line[2].to_i
		puts "Supervisor: #{array_line[0]}, Analist: #{array_line[1]}, Pending analysis: #{array_line[2]}"
		value_object << {:Supervisor => array_line[0], :Analist => array_line[1], :Pending => array_line[2]}
		#sleep 0.6 # sleep range from 0.3 to 0.6 according to CPU clock spent about 60 seconds here
	end
	puts value_object.length
end
stop = Time.now
puts ''
puts 'Finish: ' + stop.to_s

duration = stop - start

puts 'Elapsed: ' + format("%.2f", (duration / 60).to_s)  + ' minutes'
puts 'Job ended'
