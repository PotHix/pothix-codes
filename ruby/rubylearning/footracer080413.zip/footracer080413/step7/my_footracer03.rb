# my_footracer03.rb
# My footracer program
# V0.3
# Use FootracerBase.new { ... }
# usage: ruby my_footracer03.rb <racer1 name> <racer2 name>

require 'footracerbase03'

sw = true
while FootracerBase.open { |fr|
    (fr.star_wars_style_opening_crawls; sw = false)  if sw
    fr.opening

    racer1 = Racer.new ARGV[0], 3, 1
    racer2 = Racer.new ARGV[1], 4, 1

    racer1.print "#{racer1.name} : "
    racer2.print "#{racer2.name} : "
    sleep 1

    until racer1.goal? and racer2.goal?
      unless racer1.goal?
        racer1.run
        racer1.print "*" * racer1.move
      end
      unless racer2.goal?
        racer2.run 
        racer2.print "*" * racer2.move
      end
      sleep 1
    end
   
    fr.x, fr.y = 6, 1
    fr.print "#{racer1.name} finished in #{racer1.time} sec."
    fr.x, fr.y = 7, 1
    fr.print "#{racer2.name} finished in #{racer2.time} sec."
    
    fr.ending
  }
end
