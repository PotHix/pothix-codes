# starwarsstyle00.rb
# Star Wars-stayle Opening Crawls

class FootracerBase
  LEN = 55
  BTM = 14
  
  def star_wars_style_opening_crawls
    text =<<-EOS
Episode I
THE PHANTOM MENACE
Turmoil has engulfed the
Galactic Republic. The taxation
of trade routes to outlying star
systems is in dispute.

Hoping to resolve the matter
with a blockade of deadly
battleships, the greedy Trade
Federation has stopped all
shipping to the small planet
of Naboo.

While the Congress of the
Republic endlessly debates
this alarming chain of events,
the Supreme Chanccellor has
secretly dispatched two Jedi
Knights, the guardians of
peace and justice in the
galaxy, to settle the conflict...

Quote
http://www.starwars.com/episode-iii/bts/production/f20050126/indexp2.html
EOS
 
    fr = self
 
    text = text.to_s.gsub("\n", ' ')
    lines = []
    lines << $~[0] until text.slice!(/.{#{LEN}}/).nil?
    lines << text

    fr.show_telops lines
    fr.show_crawls lines
    fr.clear_msgs
  end
  
  def show_telops lines
    fr = self
    msgs = []
    lines.each{|line|
      LEN.times{|n|
        fr.x, fr.y = BTM, LEN - n-1
        fr.print line[0..n]
        sleep 0.1
      }
      sleep 1
      fr.x, fr.y = BTM, 0
      fr.print ' ' * LEN
      fr.show_msgs msgs << line
    }
  end
  
  def show_crawls lines
    fr = self
    msgs = mk_msgs lines
    n = msgs.size
    0.upto(n) do |i|
      fr.show_msgs msgs
      i == 0 ? sleep(3) : sleep(1)
      msgs.shift
      msgs << ' ' * LEN
      msgs = mk_msgs msgs
    end
    sleep 1
  end
  
  def mk_msgs lines
    n = LEN / 2
    lines.collect do |line|
      n -= 2 if n > 2
      ' ' * n + line[n...LEN-n] + ' ' * n
    end
  end
      
  def show_msgs msgs
    fr = self
    n = BTM - 2
    msgs.reverse_each do |msg|
      fr.x, fr.y = n , 0
      n -= 1
      print ' ' * LEN
      print msg
    end
  end
  
  def clear_msgs
    fr = self
    0.upto(BTM) do |n|
      fr.x, fr.y = n, 0
      print ' ' * LEN
    end
  end
  
end
