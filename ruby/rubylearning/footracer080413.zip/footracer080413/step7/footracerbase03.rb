#footracerbase03.rb
# V0.3
# Setting Foot Race Game named 'footracer'

require 'curses'
include Curses
require 'uimodules00'
require 'racer02'

class FootracerBase
  include Print
  
  def self.open *args
    if block_given?
      begin
        fr = self.new args
        again = yield fr
      ensure
        fr.close
        return again
      end
    else
      self.new args
    end
  end

  def initialize args
    $START, $GOAL = args.first.nil? ? [10, 30] : args
    @x = @y = 0
    init_screen
  end
  attr_accessor :x, :y
  
  def close
    close_screen
  end
  
  def opening
    self.x, self.y = 0, 0
    print "FootRace Sart!\n" , ' ' * $GOAL , "|Goal|"
  end
  
  def ending
    @x += 3
    @y = 0
    print "Again? (y/n): "
    /y|Y/ === getch.chr
  end
  
end

require 'starwarsstyle00'
