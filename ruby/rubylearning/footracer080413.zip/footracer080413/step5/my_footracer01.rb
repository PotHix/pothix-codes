# my_footracer01.rb
# My footracer program
# V0.1
# Use FootracerBase.new { ... }
# usage: ruby my_footracer01.rb <racer1 name> <racer2 name>

require 'footracerbase01'

while FootracerBase.open {

    racer1 = Racer.new ARGV[0]
    racer2 = Racer.new ARGV[1]

    setpos 0, 0
    addstr "FootRace Sart!\n"
    addstr ' ' * (10 + $GOAL) + "|Goal|"

    setpos 3, 1
    addstr "#{racer1.name} : "
    setpos 4, 1
    addstr "#{racer2.name} : "
    refresh

    until racer1.goal? and racer2.goal?
      racer1.run unless racer1.goal?
      setpos 3 , (10 + racer1.dist - racer1.move)
      addstr "*" * racer1.move
      refresh
      racer2.run unless racer2.goal?
      setpos 4 , (10 + racer2.dist - racer2.move)
      addstr "*" * racer2.move
      refresh
      sleep 1
    end
  
    setpos 6, 1
    addstr "#{racer1.name} finished in #{racer1.time} sec."
    setpos 7, 1
    addstr "#{racer2.name} finished in #{racer2.time} sec."
    addstr "\n"
  }
end
