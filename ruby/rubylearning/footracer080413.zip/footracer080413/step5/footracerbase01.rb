#footracerbase01.rb
# V0.1
# Setting Foot Race Game named 'footracer'

require 'curses'
include Curses
require 'racer01'

class FootracerBase
  def self.open *args
    if block_given?
      begin
        fr = self.new args
        yield fr
      ensure
        again = fr.ending
        fr.close
        return again
      end
    else
      self.new args
    end
  end

  def initialize args
    $GOAL = args.first.nil? ? 30 : args.first
    init_screen
  end
  
  def close
    close_screen
  end
  
  def ending
    addstr "\n\nAgain? (y/n): "
    (/q|y/ === getch.chr)
  end
end
