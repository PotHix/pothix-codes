# racer02.rb
# Racer class
# V0.2

class Racer
  include Print
  
  def initialize name, x=0, y=0
    @name = name
    @x = x
    @y = y
    @time = @dist = @move = 0
  end
  attr_reader :name, :time, :dist, :move, :x, :y
  
  def run
    @move = rand(5)
    @dist += @move
    @y = $START + @dist - @move
    @time += 1
  end
  
  def goal?
    $START + @dist > $GOAL
  end
end
