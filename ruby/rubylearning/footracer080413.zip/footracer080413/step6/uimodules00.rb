# uimodules00.rb
# User Interface Modules

module Print
  def print *obj
    setpos self.x, self.y
    addstr obj.to_s
    refresh
  end
end