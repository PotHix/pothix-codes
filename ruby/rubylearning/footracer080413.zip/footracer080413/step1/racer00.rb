# racer00.rb
# Racer class
# V0.0

class Racer
  def initialize name
    @name = name
    @time = @dist = @move = 0
  end
  attr_reader :name, :time, :dist, :move
  
  def run
    @move = rand(5)
    @dist += @move
    @time += 1
  end
  
  def goal?
    @dist > GOAL
  end
end
