# tt_oneracer00.rb
# time trial by one racer
# V0.0
# usage: ruby tt_oneracer.rb <racer name>

require 'racer00'

GOAL = 30

racer= Racer.new ARGV[0]
puts ' ' * (racer.name.length + GOAL + 3) + "|Goal|"
print "#{racer.name} : "
until racer.goal?
  racer.run
  print '*' * racer.move
  STDOUT.flush
  sleep 1
end
puts ''
puts "#{racer.name} finished in #{racer.time} sec."
