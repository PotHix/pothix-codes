# racer.rb

class Racer
  def initialize name, x, y=10
    @name = name
    @x = x + 3
    @y = y
  end
  attr_reader :name, :x
  
  def run
    n = rand(5)
    setpos @x, @y
    addstr "*" * n
    @y += n
    refresh
  end
  
  def goal?
    @y > GOAL
  end
end
