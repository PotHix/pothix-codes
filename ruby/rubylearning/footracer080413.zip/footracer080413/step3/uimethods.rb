# uimethods.rb
# User Interface methods

def initializing
  puts "Welcom to Footrace!"
  print "Input Racers(ex. Satoshi,Anteaya,...):"

  course = 0
  racers = gets.split(/,/).map {|racer| Racer.new(racer.strip, course+=1)}
  init_screen
  setpos 2, 0
  addstr "Footrace Started!\n"
  racers.each do |racer|
    setpos racer.x, 1
    addstr racer.name
  end
  (0...racers.size).each do |x|
    setpos x + 4, GOAL
    addstr '|'
  end
  return racers
end

def ending racers, winners
  setpos racers.size + 5, 0
  addstr 'Winners: '
  winners.each do |winner|
    addstr winner.name + '  '
  end
  addstr "\n\nAgain? (y/n): "
  again = (/q|y/ === getch.chr)
  close_screen
  return again
end