# footracer.rb

require 'curses'
include Curses
require 'racer'
require 'uimethods'

GOAL = 60

again = true
while again
  racers = initializing
  while (winners = racers.map{|racer| racer if racer.goal?} - [nil]).empty?
    racers.each {|racer| racer.run}
    sleep 1
  end
  again = ending(racers, winners)
end

puts "See you!"
puts ''