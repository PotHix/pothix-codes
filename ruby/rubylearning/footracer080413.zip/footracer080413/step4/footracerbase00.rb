#footracerbase00.rb
# V0.0
# Setting Foot Race Game named 'footracer'

require 'curses'
include Curses
require 'racer01'

class FootracerBase
  def self.open *args
    self.new args
  end

  def initialize args
    $GOAL = args.first.nil? ? 30 : args.first
    init_screen
  end
  
  def close
    close_screen
  end
end
